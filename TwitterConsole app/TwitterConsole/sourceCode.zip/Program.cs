﻿using System;
using System.Diagnostics;
using System.Linq;
using TweetSharp;


namespace TwitterConsole
{
    class Program
    {
        public const string consumerKey = "ebkfRcZj1xkyENq0iBK8JdsQQ";
        public const string consumerSecret = "2c5NiLZZGdUX5PR9jYrLoUhGhgGdj8KJ0Vj6IpS1ZmFxATu96c";
        static void Main(string[] args)
        {
            var service = new TwitterService(consumerKey, consumerSecret);

            var requestToken = service.GetRequestToken();

            var uri = service.GetAuthorizationUri(requestToken);
            Process.Start(uri.ToString());

            var verifier = Console.ReadLine();
            var access = service.GetAccessToken(requestToken, verifier);

            service.AuthenticateWith(access.Token, access.TokenSecret);

            var tweets = service.ListTweetsOnHomeTimeline(new ListTweetsOnHomeTimelineOptions()).ToList();
            

            for (int i = 0; i < 20; i++)
            {
                TimeSpan longPeriod = DateTime.Now.Subtract(tweets[i].CreatedDate);
                Console.WriteLine(tweets[i].Text);
                Console.WriteLine("This tweet have {0} days since it was published", longPeriod.Days);
                Console.WriteLine("This tweet have {0} hours since it was published", longPeriod.Hours);
                Console.WriteLine("This tweet have {0} minutes since it was published", longPeriod.Minutes);
                Console.WriteLine("  |");
                Console.WriteLine("  |");
                Console.WriteLine("  |");
            }

            var trends = service.ListLocalTrendsFor(new ListLocalTrendsForOptions() { Id = 1 }); // 1 - весь мир

            foreach (var trend in trends)
            {
                Console.WriteLine(trend.Name);
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
